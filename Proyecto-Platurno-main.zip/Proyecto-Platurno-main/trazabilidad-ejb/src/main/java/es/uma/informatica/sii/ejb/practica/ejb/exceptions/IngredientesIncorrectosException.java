package es.uma.informatica.sii.ejb.practica.ejb.exceptions;

public class IngredientesIncorrectosException extends TrazabilidadException {

}
