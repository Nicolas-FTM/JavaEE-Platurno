package es.uma.informatica.sii.ejb.practica.ejb;

public class MatriculaEJBException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	public MatriculaEJBException() {
		super();
	}
	
	public MatriculaEJBException(String msg) {
		super(msg);
	}

}
