package es.uma.informatica.sii.ejb.practica.ejb.exceptions;

public class PlaturnoException extends Exception {
    public PlaturnoException(){

    }
    public PlaturnoException(String cadena){
        super(cadena);
    }
}
