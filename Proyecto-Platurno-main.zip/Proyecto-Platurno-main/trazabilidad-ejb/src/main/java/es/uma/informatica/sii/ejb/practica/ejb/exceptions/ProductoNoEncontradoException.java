package es.uma.informatica.sii.ejb.practica.ejb.exceptions;

public class ProductoNoEncontradoException extends TrazabilidadException {

}
