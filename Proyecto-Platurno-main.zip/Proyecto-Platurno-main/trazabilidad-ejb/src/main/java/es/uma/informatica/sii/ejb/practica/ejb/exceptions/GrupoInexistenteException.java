package es.uma.informatica.sii.ejb.practica.ejb.exceptions;

public class GrupoInexistenteException extends Exception {
	public GrupoInexistenteException() {
		
	}
	public GrupoInexistenteException(String s) {
		super(s);
	}
}
