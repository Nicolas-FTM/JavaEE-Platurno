package es.uma.informatica.sii.ejb.practica.ejb.exceptions;

public class TitulacionInexistente extends Exception {
		public TitulacionInexistente(){

	    }
	    public TitulacionInexistente(String msg){
	        super(msg);
	    }
}

