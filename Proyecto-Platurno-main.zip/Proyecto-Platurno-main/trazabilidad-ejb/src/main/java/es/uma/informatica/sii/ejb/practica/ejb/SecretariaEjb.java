package es.uma.informatica.sii.ejb.practica.ejb;

public class SecretariaEjb implements SecretariaInterfaz{


}
