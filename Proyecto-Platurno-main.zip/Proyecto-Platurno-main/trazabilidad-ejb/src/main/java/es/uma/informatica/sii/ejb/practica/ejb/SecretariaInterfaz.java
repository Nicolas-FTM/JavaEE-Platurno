package es.uma.informatica.sii.ejb.practica.ejb;

public interface SecretariaInterfaz {
}
