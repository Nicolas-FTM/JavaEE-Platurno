package es.uma.informatica.sii.ejb.practica.ejb.exceptions;

public class GR_ASIG_GrupoNoExisteException extends Exception {

    public GR_ASIG_GrupoNoExisteException(){

    }

    public GR_ASIG_GrupoNoExisteException(String e){
        super(e);
    }
}
