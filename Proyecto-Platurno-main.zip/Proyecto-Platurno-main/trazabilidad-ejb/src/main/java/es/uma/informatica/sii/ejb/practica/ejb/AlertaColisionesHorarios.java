package es.uma.informatica.sii.ejb.practica.ejb;

import  es.uma.informatica.sii.ejb.practica.entidades.*;

public class AlertaColisionesHorarios {

}
